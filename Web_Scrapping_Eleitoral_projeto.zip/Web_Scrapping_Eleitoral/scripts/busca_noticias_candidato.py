#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
busca_noticias_candidato.py

Fluxo:
1. Pergunta ao usuário o nome do candidato a presidência.
2. (Opcional) Vasculha um diretório em busca de planilhas geradas
   anteriormente para o MESMO candidato, para não repetir notícias já
   catalogadas em execuções passadas.
3. Busca notícias sobre o candidato restritas aos domínios dos principais
   jornais/veículos jornalísticos brasileiros (busca geral + busca focada
   em título), ignorando links já encontrados em execuções anteriores.
4. Filtra os resultados para manter SOMENTE links que realmente pertencem
   ao domínio jornalístico pesquisado (descarta Wikipédia, redes sociais,
   agregadores, etc., mesmo que apareçam na busca).
5. Organiza os resultados agrupados por jornal.
6. Testa cada link (HTTP, com múltiplas tentativas e cabeçalhos realistas)
   e remove os que não estão de fato funcionando (com tolerância a
   bloqueios de proteção anti-bot, como HTTP 403).
7. Exporta o resultado final para uma planilha Excel (.xlsx), com
   agrupamento de linhas (outline/grupo) para cada jornal. O nome do
   candidato pesquisado é gravado na planilha (metadados + célula de
   título) para permitir a identificação rápida em execuções futuras.

Dependências (instale antes de rodar):
    pip install ddgs requests openpyxl

    Observação: o pacote "duckduckgo-search" foi renomeado para "ddgs".
    O script tenta importar "ddgs" primeiro e só usa o pacote antigo como
    fallback (silenciando o aviso de depreciação nesse caso).
"""

import os
import sys
import time
import random
import unicodedata
from datetime import datetime
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment
except ImportError:
    sys.exit("Erro: instale a dependência com 'pip install openpyxl'")

try:
    from ddgs import DDGS
except ImportError:
    try:
        import warnings
        warnings.filterwarnings(
            "ignore",
            message=r".*duckduckgo_search.*renamed.*",
            category=RuntimeWarning,
        )
        from duckduckgo_search import DDGS
    except ImportError:
        sys.exit(
            "Erro: instale a dependência de busca com "
            "'pip install ddgs' (pacote atual; 'duckduckgo-search' foi renomeado)"
        )


# --------------------------------------------------------------------------
# Configuração dos jornais/veículos jornalísticos e seus domínios
# --------------------------------------------------------------------------
JORNAIS = {
    "G1": "g1.globo.com",
    "O Globo": "oglobo.globo.com",
    "UOL": "uol.com.br",
    "Folha de São Paulo": "folha.uol.com.br",
    "Terra": "terra.com.br",
    "R7": "r7.com",
    "iG": "ig.com.br",
    "Metrópoles": "metropoles.com",
    "Poder360": "poder360.com.br",
    "Estadão": "estadao.com.br",
    "Correio Braziliense": "correiobraziliense.com.br",
    "Valor Econômico": "valor.globo.com",
    "Zero Hora / GaúchaZH": "gauchazh.clicrbs.com.br",
    "O Popular": "opopular.com.br",
    "CNN Brasil": "cnnbrasil.com.br",
    "Veja": "veja.abril.com.br",
    "Exame": "exame.com",
    "IstoÉ": "istoe.com.br",
    "CartaCapital": "cartacapital.com.br",
    "Gazeta do Povo": "gazetadopovo.com.br",
    "Brasil 247": "brasil247.com",
    "Jovem Pan": "jovempan.com.br",
    "Congresso em Foco": "congressoemfoco.uol.com.br",
    "A Tarde": "atarde.com.br",
    "O Tempo": "otempo.com.br",
    "Correio do Povo": "correiodopovo.com.br",
    "Agência Brasil": "agenciabrasil.ebc.com.br",
    "Diário do Nordeste": "diariodonordeste.com.br",
}

# Domínios que NUNCA devem ser aceitos como resultado jornalístico,
# mesmo que apareçam na busca (rede social, enciclopédia colaborativa,
# agregador, vídeo, etc.)
DOMINIOS_BLOQUEADOS = {
    "wikipedia.org", "instagram.com", "facebook.com", "twitter.com", "x.com",
    "youtube.com", "youtu.be", "linkedin.com", "tiktok.com", "threads.net",
    "t.me", "reddit.com", "pinterest.com", "google.com", "bing.com",
    "duckduckgo.com", "amazon.com", "mercadolivre.com.br", "wikiwand.com",
    "web.archive.org", "wordpress.com", "blogspot.com", "medium.com",
}

MAX_RESULTADOS_POR_JORNAL = 500
# Observação: o mecanismo de busca (DuckDuckGo) pode, na prática, retornar
# menos resultados do que o solicitado para termos muito específicos -
# 500 é o TETO desejado, não uma garantia por jornal.
TIMEOUT_CONEXAO = (6, 15)          # (timeout de conexão, timeout de leitura) em segundos
PAUSA_ENTRE_BUSCAS = 1.5
MAX_TENTATIVAS_LINK = 4

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.0 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    # Muitos sites de notícia liberam crawlers conhecidos (para indexação/SEO)
    # mesmo bloqueando outros bots -- útil como última tentativa antes de
    # considerar um link quebrado.
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
]

# Códigos HTTP que costumam indicar bloqueio de proteção anti-bot
# (Cloudflare, Akamai, WAFs em geral) e NÃO necessariamente um link quebrado.
CODIGOS_POSSIVEL_BLOQUEIO_BOT = {403, 429, 999}
# Códigos que realmente indicam que o conteúdo não existe mais.
CODIGOS_ERRO_DEFINITIVO = {400, 404, 405, 410, 451}


def montar_sessao() -> requests.Session:
    """Cria uma sessão HTTP com retentativas automáticas para erros transitórios."""
    sessao = requests.Session()
    retries = Retry(
        total=2,
        backoff_factor=1.2,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "HEAD"],
        raise_on_status=False,
    )
    adaptador = HTTPAdapter(max_retries=retries)
    sessao.mount("https://", adaptador)
    sessao.mount("http://", adaptador)
    return sessao


SESSAO_HTTP = montar_sessao()


# --------------------------------------------------------------------------
# Filtro de domínio: garante que o link pertence de fato ao jornal buscado
# --------------------------------------------------------------------------
def extrair_dominio(url: str) -> str:
    """
    Extrai o domínio (netloc) de uma URL de forma tolerante:
    - Se a URL vier sem esquema (ex: "g1.globo.com/materia" ou
      "//g1.globo.com/materia"), completa com "https://" antes de
      analisar, evitando que links válidos sejam descartados só por
      causa da formatação retornada pela biblioteca de busca.
    """
    url = url.strip()
    parsed = urlparse(url)
    netloc = parsed.netloc.lower()

    if not netloc:
        url_normalizada = url.lstrip("/")
        if not url_normalizada.startswith(("http://", "https://")):
            url_normalizada = "https://" + url_normalizada
        parsed = urlparse(url_normalizada)
        netloc = parsed.netloc.lower()

    if netloc.startswith("www."):
        netloc = netloc[4:]

    return netloc


def pertence_ao_dominio(netloc: str, dominio_alvo: str) -> bool:
    dominio_alvo = dominio_alvo.lower()
    return netloc == dominio_alvo or netloc.endswith("." + dominio_alvo)


def esta_bloqueado(netloc: str) -> bool:
    for bloqueado in DOMINIOS_BLOQUEADOS:
        if pertence_ao_dominio(netloc, bloqueado):
            return True
    return False


def eh_link_jornalistico_valido(url: str, dominio_alvo: str) -> bool:
    """
    Retorna True apenas se o link:
    - tiver um domínio (netloc) válido;
    - não estiver na lista de domínios bloqueados (redes sociais, wikipedia etc.);
    - pertencer de fato ao domínio do jornal pesquisado;
    - não pertencer, de forma mais específica, a OUTRO jornal configurado
      (evita, por exemplo, uma notícia do Congresso em Foco ser contada
      como se fosse da UOL só porque o domínio contém "uol.com.br").
    """
    netloc = extrair_dominio(url)
    if not netloc:
        return False
    if esta_bloqueado(netloc):
        return False
    if not pertence_ao_dominio(netloc, dominio_alvo):
        return False

    # Verifica se algum OUTRO domínio configurado é uma correspondência
    # mais específica (mais longa) do que o domínio alvo -> nesse caso,
    # o link pertence a outro veículo, não ao que está sendo buscado agora.
    for outro_dominio in JORNAIS.values():
        if outro_dominio == dominio_alvo:
            continue
        if pertence_ao_dominio(netloc, outro_dominio) and len(outro_dominio) > len(dominio_alvo):
            return False

    return True


# --------------------------------------------------------------------------
# Verificação de planilhas já existentes (evita repetir notícias entre execuções)
# --------------------------------------------------------------------------
def normalizar_texto(texto: str) -> str:
    """Remove acentos, caixa e espaços extras para comparar nomes com segurança."""
    if not texto:
        return ""
    texto = texto.strip().lower()
    sem_acentos = "".join(
        c for c in unicodedata.normalize("NFKD", texto) if not unicodedata.combining(c)
    )
    return " ".join(sem_acentos.split())


def localizar_planilhas_xlsx(diretorio: str) -> list:
    """Procura, recursivamente, todos os arquivos .xlsx de um diretório."""
    caminhos = []
    for raiz, _subpastas, arquivos in os.walk(diretorio):
        for nome in arquivos:
            if nome.lower().endswith(".xlsx") and not nome.startswith("~$"):
                caminhos.append(os.path.join(raiz, nome))
    return caminhos


def ler_candidato_da_planilha(caminho: str):
    """
    Lê, de forma rápida, qual candidato está associado a uma planilha
    gerada por este script. Primeiro tenta os metadados internos do
    arquivo (rápido, não exige ler as linhas de dados); se não encontrar
    (ex: planilha de uma versão antiga do script), tenta a célula de
    título na primeira linha da aba de notícias.
    """
    try:
        wb = load_workbook(caminho, read_only=True)
    except Exception as exc:
        print(f"    [AVISO] Não foi possível abrir '{caminho}': {exc}")
        return None

    candidato_meta = None
    try:
        props = wb.properties
        candidato_meta = props.keywords or props.subject or None
    except Exception:
        candidato_meta = None

    if not candidato_meta:
        try:
            aba = wb["Noticias"] if "Noticias" in wb.sheetnames else wb.active
            primeira_celula = aba.cell(row=1, column=1).value
            if primeira_celula and "Pesquisa:" in str(primeira_celula):
                trecho = str(primeira_celula).split("Pesquisa:", 1)[1]
                candidato_meta = trecho.split("—")[0].split("(")[0].strip()
        except Exception:
            candidato_meta = None

    wb.close()
    return candidato_meta


def ler_links_existentes_arquivo(caminho: str) -> dict:
    """
    Lê uma planilha já gerada por este script e devolve um dicionário
    {jornal: {links}} com todos os links catalogados nela. A identificação
    do "início de um grupo" é feita comparando a coluna A com os nomes
    de jornal atualmente configurados em JORNAIS -- isso funciona
    independentemente de haver ou não uma linha de título acima.
    """
    dados = {}
    try:
        wb = load_workbook(caminho, read_only=True, data_only=True)
        aba = wb["Noticias"] if "Noticias" in wb.sheetnames else wb.active

        jornal_atual = None
        for linha in aba.iter_rows(values_only=True):
            if not linha:
                continue
            col_a = linha[0] if len(linha) > 0 else None
            col_c = linha[2] if len(linha) > 2 else None

            if col_a and col_a in JORNAIS:
                jornal_atual = col_a
                continue

            if col_c and jornal_atual:
                dados.setdefault(jornal_atual, set()).add(str(col_c).strip())

        wb.close()
    except Exception as exc:
        print(f"    [AVISO] Não foi possível ler notícias de '{caminho}': {exc}")

    return dados


def escanear_historico(diretorio: str, candidato: str) -> set:
    """
    Varre o diretório informado em busca de planilhas já geradas para o
    MESMO candidato (comparação tolerante a acentos/maiúsculas) e retorna
    o conjunto de todos os links já catalogados anteriormente, para que
    a nova busca não repita essas notícias.
    """
    candidato_normalizado = normalizar_texto(candidato)
    caminhos = localizar_planilhas_xlsx(diretorio)

    links_existentes = set()
    arquivos_relevantes = 0

    print(f"\nVerificando planilhas existentes em '{diretorio}' para o candidato '{candidato}'...")
    print(f"    {len(caminhos)} arquivo(s) .xlsx encontrado(s) no diretório.")

    for caminho in caminhos:
        candidato_arquivo = ler_candidato_da_planilha(caminho)
        if not candidato_arquivo:
            continue
        if normalizar_texto(candidato_arquivo) != candidato_normalizado:
            continue

        arquivos_relevantes += 1
        links_por_jornal = ler_links_existentes_arquivo(caminho)
        total_arquivo = sum(len(v) for v in links_por_jornal.values())
        print(f"    [ENCONTRADO] {caminho}  ({total_arquivo} link(s))")
        for links in links_por_jornal.values():
            links_existentes.update(links)

    if arquivos_relevantes == 0:
        print("    Nenhuma planilha anterior encontrada para esse candidato.")
    else:
        print(
            f"    Total: {arquivos_relevantes} planilha(s) relevante(s), "
            f"{len(links_existentes)} link(s) já catalogado(s) anteriormente "
            f"(serão ignorados na nova busca)."
        )

    return links_existentes


def escolher_diretorio_historico():
    """
    Pergunta ao usuário se deseja verificar planilhas já existentes antes
    de buscar (para não repetir notícias) e, em caso positivo, pede o
    diretório onde essas planilhas estão salvas.
    Retorna (usar_historico: bool, diretorio: str ou None).
    """
    resposta = input(
        "\nDeseja verificar planilhas já existentes de execuções anteriores "
        "para não repetir notícias do mesmo candidato? (s/n) "
    ).strip().lower()

    if resposta not in ("s", "sim", "y", "yes"):
        return False, None

    while True:
        entrada = input(
            "Informe o diretório onde estão as planilhas anteriores "
            "(Enter para cancelar a verificação): "
        ).strip()

        if not entrada:
            print("    Nenhum diretório informado. Seguindo sem verificar duplicados.")
            return False, None

        caminho = os.path.abspath(os.path.expanduser(entrada))
        if os.path.isdir(caminho):
            return True, caminho

        print(f"    [ERRO] '{caminho}' não é uma pasta válida. Tente novamente.")


# --------------------------------------------------------------------------
# Relevância: prioriza notícias em que o candidato é mais citado
# --------------------------------------------------------------------------
def calcular_pontuacao_relevancia(titulo: str, corpo: str, candidato: str) -> int:
    """
    Calcula uma pontuação de relevância com base em quantas vezes o nome do
    candidato (completo e por partes, ex: sobrenome) aparece no título e no
    corpo/trecho da notícia. Menções no título valem mais do que no corpo,
    pois indicam que a notícia é realmente sobre o candidato.
    """
    titulo_lower = (titulo or "").lower()
    corpo_lower = (corpo or "").lower()
    candidato_lower = candidato.strip().lower()

    pontos = 0
    pontos += titulo_lower.count(candidato_lower) * 5
    pontos += corpo_lower.count(candidato_lower) * 2

    # Partes do nome (ex: sobrenome), ignorando conectores curtos como "de", "da"
    partes_nome = [p for p in candidato_lower.split() if len(p) > 2]
    for parte in partes_nome:
        pontos += titulo_lower.count(parte) * 2
        pontos += corpo_lower.count(parte) * 1

    return pontos


# --------------------------------------------------------------------------
# Etapa 1/2/3: Buscar e já filtrar por domínio jornalístico
# --------------------------------------------------------------------------
def buscar_noticias_por_jornal(
    candidato: str, jornal: str, dominio: str, links_para_ignorar: set
) -> tuple:
    """
    Faz duas buscas complementares para cada jornal (geral + focada em
    título), filtra por domínio jornalístico, pontua por relevância e
    ignora links que já apareceram em planilhas de execuções anteriores
    para o mesmo candidato.
    Retorna (lista_de_noticias, quantidade_ignorada_por_ja_existir).
    """
    queries = [
        f'"{candidato}" site:{dominio}',
        f'intitle:"{candidato}" site:{dominio}',
    ]

    encontrados = {}  # link -> {"titulo", "link", "pontuacao"}
    ignorados_por_duplicidade = 0

    for query in queries:
        try:
            with DDGS() as ddgs:
                for item in ddgs.text(query, region="br-pt", max_results=MAX_RESULTADOS_POR_JORNAL):
                    titulo = (item.get("title") or "").strip()
                    corpo = (item.get("body") or item.get("description") or "").strip()
                    link = (item.get("href") or item.get("link") or "").strip()

                    if not titulo or not link:
                        continue

                    if link in links_para_ignorar:
                        ignorados_por_duplicidade += 1
                        continue

                    if not eh_link_jornalistico_valido(link, dominio):
                        dominio_detectado = extrair_dominio(link) or "(indetectável)"
                        print(
                            f"    [DESCARTADO - fora do domínio jornalístico] "
                            f"{link}  (domínio detectado: {dominio_detectado})"
                        )
                        continue

                    pontuacao = calcular_pontuacao_relevancia(titulo, corpo, candidato)
                    if pontuacao <= 0:
                        # nome do candidato não foi realmente encontrado
                        # no título/trecho -> provável falso positivo da busca
                        continue

                    # Se o mesmo link já apareceu na outra busca, mantém a
                    # maior pontuação entre as duas.
                    existente = encontrados.get(link)
                    if existente is None or pontuacao > existente["pontuacao"]:
                        encontrados[link] = {
                            "titulo": titulo,
                            "link": link,
                            "pontuacao": pontuacao,
                        }
        except Exception as exc:
            print(f"  [AVISO] Falha ao buscar em {jornal} ({dominio}) com a query '{query}': {exc}")

    # Ordena da notícia mais relevante (mais citações, sobretudo no título)
    # para a menos relevante, e limita ao total configurado.
    resultados_ordenados = sorted(
        encontrados.values(), key=lambda n: n["pontuacao"], reverse=True
    )[:MAX_RESULTADOS_POR_JORNAL]

    # Remove o campo auxiliar de pontuação antes de retornar
    lista_final = [{"titulo": n["titulo"], "link": n["link"]} for n in resultados_ordenados]
    return lista_final, ignorados_por_duplicidade


def buscar_todas_as_noticias(candidato: str, links_para_ignorar: set) -> dict:
    dados = {}
    total_jornais = len(JORNAIS)

    for i, (jornal, dominio) in enumerate(JORNAIS.items(), start=1):
        print(f"[{i}/{total_jornais}] Buscando notícias de '{candidato}' em {jornal}...")
        noticias, ignorados = buscar_noticias_por_jornal(candidato, jornal, dominio, links_para_ignorar)
        dados[jornal] = noticias
        msg = f"    -> {len(noticias)} notícia(s) jornalística(s) nova(s) encontrada(s)"
        if ignorados:
            msg += f" ({ignorados} já catalogada(s) anteriormente, ignorada(s))"
        print(msg)
        time.sleep(PAUSA_ENTRE_BUSCAS + random.uniform(0, 0.7))

    return dados


# --------------------------------------------------------------------------
# Etapa 5: Testar se os links estão funcionando (validação mais precisa)
# --------------------------------------------------------------------------
def montar_headers(user_agent: str) -> dict:
    return {
        "User-Agent": user_agent,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": "https://www.google.com/",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "cross-site",
    }


def link_esta_funcionando(url: str) -> tuple:
    """
    Testa se um link responde com sucesso. Faz até MAX_TENTATIVAS_LINK
    tentativas, alternando User-Agent (incluindo um crawler conhecido,
    já que muitos sites bloqueiam bots genéricos mas liberam crawlers de
    busca) e usando GET (mais confiável que HEAD).

    Retorna uma tupla (esta_ok: bool, motivo: str), onde motivo indica
    se o link foi confirmado normalmente ou aceito por heurística de
    bloqueio anti-bot (para fins de log/transparência).

    Regras:
    - Qualquer tentativa com status < 400 -> considerado funcionando.
    - Qualquer tentativa com status em CODIGOS_ERRO_DEFINITIVO (404, 410
      etc.) -> considerado quebrado imediatamente (esses códigos indicam
      que o conteúdo realmente não existe mais).
    - Se TODAS as tentativas resultarem em 403/429/999 (sem nenhum erro
      definitivo), o link é mantido como "provavelmente válido", pois
      esse padrão é típico de proteção anti-bot (Cloudflare/WAF) e não
      de conteúdo removido.
    """
    houve_bloqueio_bot = False
    ultimo_erro = None

    for tentativa in range(MAX_TENTATIVAS_LINK):
        user_agent = USER_AGENTS[tentativa % len(USER_AGENTS)]
        headers = montar_headers(user_agent)
        verificar_ssl = tentativa < MAX_TENTATIVAS_LINK - 1

        try:
            resposta = SESSAO_HTTP.get(
                url,
                headers=headers,
                timeout=TIMEOUT_CONEXAO,
                allow_redirects=True,
                stream=True,
                verify=verificar_ssl,
            )
            resposta.close()

            if resposta.status_code < 400:
                return True, "ok"

            if resposta.status_code in CODIGOS_ERRO_DEFINITIVO:
                ultimo_erro = f"HTTP {resposta.status_code}"
                return False, ultimo_erro

            if resposta.status_code in CODIGOS_POSSIVEL_BLOQUEIO_BOT:
                houve_bloqueio_bot = True
                ultimo_erro = f"HTTP {resposta.status_code}"
                time.sleep(1.5)
                continue

            # Outros códigos inesperados (ex: 5xx persistente mesmo após
            # os retries automáticos da sessão) -> considera quebrado.
            ultimo_erro = f"HTTP {resposta.status_code}"
            return False, ultimo_erro

        except requests.exceptions.SSLError as exc:
            ultimo_erro = f"SSLError: {exc}"
            continue
        except requests.exceptions.Timeout as exc:
            ultimo_erro = f"Timeout: {exc}"
            time.sleep(1.0)
            continue
        except requests.exceptions.RequestException as exc:
            ultimo_erro = f"{type(exc).__name__}: {exc}"
            time.sleep(1.0)
            continue

    # Esgotadas as tentativas: se todas as respostas obtidas foram
    # bloqueios típicos de anti-bot (403/429/999), assume-se que o link
    # está no ar, apenas protegido contra scripts -> mantém na lista.
    if houve_bloqueio_bot:
        return True, f"mantido (bloqueio anti-bot: {ultimo_erro})"

    return False, ultimo_erro or "falha desconhecida"


def filtrar_links_validos(dados: dict) -> dict:
    dados_validos = {}

    for jornal, noticias in dados.items():
        if not noticias:
            dados_validos[jornal] = []
            continue

        print(f"Testando {len(noticias)} link(s) de {jornal}...")
        noticias_ok = []
        for noticia in noticias:
            ok, motivo = link_esta_funcionando(noticia["link"])
            if ok:
                if motivo != "ok":
                    print(f"    [{motivo.upper()}] {noticia['link']}")
                noticias_ok.append(noticia)
            else:
                print(f"    [REMOVIDO - {motivo}] {noticia['link']}")
        dados_validos[jornal] = noticias_ok

    return dados_validos


# --------------------------------------------------------------------------
# Escolha do diretório onde a planilha será salva
# --------------------------------------------------------------------------
def escolher_diretorio_destino() -> str:
    """
    Pergunta ao usuário em qual pasta a planilha deve ser salva.
    - Se o usuário não digitar nada, usa o diretório atual.
    - Expande "~" para a pasta do usuário.
    - Se a pasta não existir, pergunta se deseja criá-la.
    - Repete a pergunta caso o caminho informado seja inválido (ex: aponte
      para um arquivo já existente) ou a criação seja recusada/falhe.
    """
    diretorio_padrao = os.getcwd()

    while True:
        entrada = input(
            f"\nEm qual pasta deseja salvar a planilha? "
            f"(Enter para usar a pasta atual: {diretorio_padrao})\n> "
        ).strip()

        if not entrada:
            return diretorio_padrao

        caminho = os.path.expanduser(entrada)
        caminho = os.path.abspath(caminho)

        if os.path.isfile(caminho):
            print(f"    [ERRO] '{caminho}' é um arquivo, não uma pasta. Tente novamente.")
            continue

        if os.path.isdir(caminho):
            return caminho

        resposta = input(
            f"    A pasta '{caminho}' não existe. Deseja criá-la agora? (s/n) "
        ).strip().lower()

        if resposta in ("s", "sim", "y", "yes"):
            try:
                os.makedirs(caminho, exist_ok=True)
                return caminho
            except OSError as exc:
                print(f"    [ERRO] Não foi possível criar a pasta: {exc}. Tente outro caminho.")
                continue
        else:
            print("    Ok, informe outro caminho.")
            continue


# --------------------------------------------------------------------------
# Etapa 6: Exportar para Excel, agrupado por jornal
# --------------------------------------------------------------------------
def exportar_para_excel(dados: dict, candidato: str, diretorio_destino: str) -> str:
    wb = Workbook()
    ws = wb.active
    ws.title = "Noticias"

    # Grava o candidato pesquisado nos metadados internos do arquivo
    # (permite identificação rápida em execuções futuras, sem precisar
    # ler todas as linhas de dados) e também na planilha propriamente
    # dita, para conferência visual do usuário.
    wb.properties.subject = candidato
    wb.properties.keywords = normalizar_texto(candidato)
    wb.properties.title = f"Notícias - {candidato}"

    timestamp_geracao = datetime.now().strftime("%d/%m/%Y %H:%M")
    ws.merge_cells("A1:C1")
    ws["A1"] = f"Pesquisa: {candidato}  —  Gerado em {timestamp_geracao}"
    ws["A1"].font = Font(bold=True, italic=True, size=12)
    ws["A1"].alignment = Alignment(horizontal="left")

    ws["A2"] = "Jornal"
    ws["B2"] = "Título da Notícia"
    ws["C2"] = "Link"
    for col in ("A2", "B2", "C2"):
        ws[col].font = Font(bold=True, color="FFFFFF")
        ws[col].fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
        ws[col].alignment = Alignment(horizontal="center")

    linha_atual = 3
    fill_jornal = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")

    for jornal, noticias in dados.items():
        ws.cell(row=linha_atual, column=1, value=jornal)
        ws.cell(row=linha_atual, column=2, value=f"{len(noticias)} notícia(s) válida(s)")
        for col in (1, 2, 3):
            ws.cell(row=linha_atual, column=col).font = Font(bold=True)
            ws.cell(row=linha_atual, column=col).fill = fill_jornal
        linha_atual += 1

        if not noticias:
            ws.cell(row=linha_atual, column=2, value="(nenhum link válido encontrado)")
            ws.row_dimensions[linha_atual].outlineLevel = 1
            linha_atual += 1
            continue

        for noticia in noticias:
            ws.cell(row=linha_atual, column=2, value=noticia["titulo"])
            celula_link = ws.cell(row=linha_atual, column=3, value=noticia["link"])
            celula_link.hyperlink = noticia["link"]
            celula_link.font = Font(color="0563C1", underline="single")
            ws.row_dimensions[linha_atual].outlineLevel = 1
            linha_atual += 1

    ws.sheet_properties.outlinePr.summaryBelow = False
    ws.sheet_properties.outlinePr.summaryAbove = True

    for col, largura in {"A": 24, "B": 60, "C": 55}.items():
        ws.column_dimensions[col].width = largura

    ws.freeze_panes = "A3"

    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    candidato_slug = "_".join(candidato.strip().split())
    nome_arquivo = f"noticias_{candidato_slug}_{timestamp}.xlsx"
    caminho_completo = os.path.join(diretorio_destino, nome_arquivo)
    wb.save(caminho_completo)
    return caminho_completo


# --------------------------------------------------------------------------
# Programa principal
# --------------------------------------------------------------------------
def main():
    print("=" * 70)
    print("Busca de notícias de candidato a presidência nos principais jornais")
    print("=" * 70)

    candidato = input("\nDigite o nome do candidato: ").strip()
    if not candidato:
        sys.exit("Nenhum nome informado. Encerrando.")

    usar_historico, diretorio_historico = escolher_diretorio_historico()
    links_ja_existentes = set()
    if usar_historico:
        links_ja_existentes = escanear_historico(diretorio_historico, candidato)

    print(f"\nIniciando busca de notícias sobre '{candidato}'...\n")
    dados_brutos = buscar_todas_as_noticias(candidato, links_ja_existentes)

    total_bruto = sum(len(v) for v in dados_brutos.values())
    print(f"\nTotal de notícias jornalísticas encontradas (antes da validação de link): {total_bruto}")

    print("\nValidando links...\n")
    dados_validos = filtrar_links_validos(dados_brutos)

    total_valido = sum(len(v) for v in dados_validos.values())
    print(f"\nTotal de notícias com link confirmado funcionando: {total_valido}")

    diretorio_destino = escolher_diretorio_destino()

    print("\nGerando planilha Excel...")
    arquivo_gerado = exportar_para_excel(dados_validos, candidato, diretorio_destino)
    print(f"\nConcluído! Arquivo gerado: {arquivo_gerado}")


if __name__ == "__main__":
    main()
