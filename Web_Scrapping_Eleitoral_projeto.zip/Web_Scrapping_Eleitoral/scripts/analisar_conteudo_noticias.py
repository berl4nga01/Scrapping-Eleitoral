#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analisar_conteudo_noticias.py

Fluxo:
1. Lê os links (jornal/título/link) de UMA OU MAIS planilhas .xlsx geradas
   pelo script "busca_noticias_candidato.py" (o usuário informa quantas
   quiser). Os links são combinados e deduplicados entre as planilhas.
2. Acessa cada link e extrai o conteúdo de texto completo da notícia, com
   duas estratégias de extração combinadas (trafilatura + fallback via
   BeautifulSoup) e "aquecimento" de domínio (visita a página inicial do
   site antes do artigo, o que ajuda a obter cookies/sessão em sites com
   proteção anti-bot) para reduzir ao máximo as falhas de coleta. Links que
   falham na primeira rodada passam por uma segunda tentativa.
3. Conta a frequência de cada palavra em todo o texto coletado (ignorando
   stopwords em português) e monta um ranking com as 20 palavras mais
   frequentes.
4. Gera UMA ÚNICA planilha Excel (.xlsx) com três abas:
   - "Noticias_Texto": jornal, título, link, texto completo e status da
     coleta (sucesso/falha), agrupado por jornal.
   - "Frequencia_Completa": todas as palavras e suas contagens.
   - "Top20": as 20 palavras mais citadas + gráfico de barras nativo do
     Excel.

Dependências (instale antes de rodar):
    pip install requests trafilatura beautifulsoup4 openpyxl
"""

import os
import re
import sys
import time
import threading
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

try:
    from openpyxl import load_workbook, Workbook
    from openpyxl.chart import BarChart, Reference
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    from openpyxl.utils.exceptions import IllegalCharacterError
    from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
except ImportError:
    sys.exit("Erro: instale a dependência com 'pip install openpyxl'")

try:
    import trafilatura
except ImportError:
    sys.exit("Erro: instale a dependência com 'pip install trafilatura'")

try:
    from bs4 import BeautifulSoup
except ImportError:
    sys.exit("Erro: instale a dependência com 'pip install beautifulsoup4'")


# --------------------------------------------------------------------------
# Configurações gerais
# --------------------------------------------------------------------------
MAX_TENTATIVAS_DOWNLOAD = 6
TIMEOUT_CONEXAO = (6, 20)
TIMEOUT_AQUECIMENTO = (5, 8)
MAX_TRABALHADORES_PARALELOS = 8
MAX_TRABALHADORES_SEGUNDA_RODADA = 4
TAMANHO_MINIMO_TEXTO_VALIDO = 60      # caracteres
LIMITE_CARACTERES_CELULA_EXCEL = 32000  # Excel trava em 32.767 por célula
PAUSA_ANTES_DA_SEGUNDA_RODADA = 6      # segundos, dá um respiro para sites com rate limit
TOP_N_PALAVRAS = 20

CODIGOS_ERRO_DEFINITIVO = {400, 404, 405, 410, 451}
CODIGOS_POSSIVEL_BLOQUEIO_BOT = {403, 429, 999}

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.0 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
]

STOPWORDS_PT = {
    "a", "à", "às", "ao", "aos", "aquela", "aquelas", "aquele", "aqueles",
    "aquilo", "as", "até", "com", "como", "da", "das", "de", "dela", "delas",
    "dele", "deles", "depois", "do", "dos", "e", "é", "ela", "elas", "ele",
    "eles", "em", "entre", "era", "eram", "essa", "essas", "esse", "esses",
    "esta", "está", "estamos", "estão", "estas", "estava", "estavam", "este",
    "esteja", "estejam", "estes", "esteve", "estive", "estivemos",
    "estiveram", "eu", "foi", "fomos", "for", "foram", "fosse", "fossem",
    "fui", "há", "isso", "isto", "já", "lhe", "lhes", "mais", "mas", "me",
    "mesmo", "meu", "meus", "minha", "minhas", "muito", "na", "não", "nas",
    "nem", "no", "nos", "nós", "nossa", "nossas", "nosso", "nossos", "num",
    "numa", "o", "os", "ou", "para", "pela", "pelas", "pelo", "pelos",
    "por", "qual", "quando", "que", "quem", "se", "seja", "sejam", "sem",
    "será", "serão", "seu", "seus", "só", "somos", "sou", "sua", "suas",
    "também", "te", "tem", "tém", "temos", "tenha", "tenham", "teu", "teus",
    "teve", "tinha", "tinham", "tive", "tivemos", "tiveram", "tu", "tua",
    "tuas", "um", "uma", "vocês", "vos", "isso", "aí", "ali", "então", "ainda",
    "assim", "cada", "onde", "outro", "outra", "outros", "outras", "todo",
    "toda", "todos", "todas", "sobre", "após", "durante", "diz", "disse",
    "segundo", "ser", "estar", "ter", "haver", "vai", "vão", "ano",
    "anos", "dia", "dias", "hoje", "ontem", "amanhã", "sr", "sra",
}


def montar_sessao() -> requests.Session:
    sessao = requests.Session()
    retries = Retry(
        total=2,
        backoff_factor=1.2,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
        raise_on_status=False,
    )
    adaptador = HTTPAdapter(max_retries=retries, pool_maxsize=MAX_TRABALHADORES_PARALELOS * 2)
    sessao.mount("https://", adaptador)
    sessao.mount("http://", adaptador)
    return sessao


SESSAO_HTTP = montar_sessao()

DOMINIOS_AQUECIDOS = set()
LOCK_AQUECIMENTO = threading.Lock()


def montar_headers(user_agent: str) -> dict:
    return {
        "User-Agent": user_agent,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
        # IMPORTANTE: não anunciar suporte a Brotli ("br") aqui. Sem o pacote
        # opcional "brotli"/"brotlicffi" instalado, o requests/urllib3 não
        # consegue descomprimir esse formato e devolve bytes binários como
        # se fossem texto -- o que corrompe a extração e pode travar a
        # geração da planilha. gzip/deflate já cobrem a grande maioria dos
        # sites e são sempre descomprimidos corretamente pela biblioteca.
        "Accept-Encoding": "gzip, deflate",
        "Referer": "https://www.google.com/",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
    }


def aquecer_dominio(url: str) -> None:
    """
    Visita a página inicial do domínio uma única vez por execução, antes do
    primeiro acesso a uma notícia daquele site. Alguns sites só liberam
    conteúdo depois de uma "sessão" iniciada na home (cookies de proteção
    anti-bot). Falhas aqui são ignoradas silenciosamente -- é apenas uma
    tentativa de melhorar a taxa de sucesso, não uma etapa obrigatória.
    """
    dominio = urlparse(url).netloc
    if not dominio:
        return

    with LOCK_AQUECIMENTO:
        if dominio in DOMINIOS_AQUECIDOS:
            return
        DOMINIOS_AQUECIDOS.add(dominio)

    try:
        SESSAO_HTTP.get(
            f"https://{dominio}/",
            headers=montar_headers(USER_AGENTS[0]),
            timeout=TIMEOUT_AQUECIMENTO,
            allow_redirects=True,
        )
    except requests.exceptions.RequestException:
        pass


# --------------------------------------------------------------------------
# Etapa 1: Ler os links de uma ou mais planilhas
# --------------------------------------------------------------------------
def ler_noticias_da_planilha(caminho_planilha: str) -> list:
    """
    Lê uma planilha gerada por "busca_noticias_candidato.py" e retorna uma
    lista de dicionários: [{"jornal":..., "titulo":..., "link":...}, ...]

    Leitura genérica: qualquer linha com texto na coluna A e SEM link
    válido na coluna C é tratada como cabeçalho de grupo (jornal); qualquer
    linha cuja coluna C comece com "http" é tratada como notícia.
    """
    if not os.path.isfile(caminho_planilha):
        print(f"    [AVISO] Arquivo não encontrado, ignorando: {caminho_planilha}")
        return []

    try:
        wb = load_workbook(caminho_planilha, read_only=True, data_only=True)
    except Exception as exc:
        print(f"    [AVISO] Não foi possível abrir '{caminho_planilha}': {exc}")
        return []

    aba = wb["Noticias"] if "Noticias" in wb.sheetnames else wb.active

    noticias = []
    jornal_atual = None

    for linha in aba.iter_rows(values_only=True):
        if not linha:
            continue
        col_a = linha[0] if len(linha) > 0 else None
        col_b = linha[1] if len(linha) > 1 else None
        col_c = linha[2] if len(linha) > 2 else None

        link_valido = isinstance(col_c, str) and col_c.strip().lower().startswith(("http://", "https://"))

        if col_a and not link_valido:
            texto_a = str(col_a).strip()
            if texto_a.lower() == "jornal" or texto_a.lower().startswith("pesquisa:"):
                continue
            jornal_atual = texto_a
            continue

        if link_valido and jornal_atual:
            noticias.append({
                "jornal": jornal_atual,
                "titulo": (str(col_b).strip() if col_b else "(sem título)"),
                "link": col_c.strip(),
            })

    wb.close()
    return noticias


def escolher_planilhas_entrada() -> list:
    """
    Pergunta ao usuário quantas planilhas quiser, uma por vez, até que ele
    deixe a resposta em branco (é exigida pelo menos uma planilha válida).
    """
    caminhos = []
    print("\nInforme o caminho de cada planilha .xlsx a analisar (uma por vez).")
    print("Pressione Enter sem digitar nada para encerrar a lista.")

    while True:
        numero = len(caminhos) + 1
        entrada = input(f"  Planilha {numero} (Enter para finalizar): ").strip()

        if not entrada:
            if caminhos:
                return caminhos
            print("    É necessário informar ao menos uma planilha.")
            continue

        caminho = os.path.abspath(os.path.expanduser(entrada))
        if os.path.isfile(caminho) and caminho.lower().endswith(".xlsx"):
            caminhos.append(caminho)
            print(f"    Adicionada: {caminho}")
        else:
            print(f"    [ERRO] '{caminho}' não é um arquivo .xlsx válido. Tente novamente.")


def combinar_planilhas(caminhos: list) -> list:
    """
    Lê todas as planilhas informadas e combina os resultados, removendo
    links duplicados que apareçam em mais de uma planilha (mantém a
    primeira ocorrência).
    """
    noticias_combinadas = {}
    for caminho in caminhos:
        print(f"\nLendo planilha: {caminho}")
        noticias_arquivo = ler_noticias_da_planilha(caminho)
        print(f"    {len(noticias_arquivo)} notícia(s) encontrada(s) nesta planilha.")
        for noticia in noticias_arquivo:
            chave = noticia["link"].strip().lower()
            if chave not in noticias_combinadas:
                noticias_combinadas[chave] = noticia

    lista_final = list(noticias_combinadas.values())
    print(f"\nTotal combinado (sem duplicados entre planilhas): {len(lista_final)} notícia(s).")
    return lista_final


# --------------------------------------------------------------------------
# Etapa 2: Baixar e extrair o texto de cada notícia (com fallback duplo)
# --------------------------------------------------------------------------
def conteudo_parece_binario(texto: str) -> bool:
    """
    Verifica, por amostragem, se um texto supostamente HTML na verdade é
    conteúdo binário/corrompido (ex: falha na descompressão da resposta).
    Conta a proporção de caracteres de controle não imprimíveis (fora
    tab/quebra de linha) numa amostra do início do texto; um HTML real
    tem essa proporção próxima de zero.
    """
    if not texto:
        return False
    amostra = texto[:4000]
    if not amostra:
        return False
    caracteres_de_controle = sum(
        1 for c in amostra if ord(c) < 32 and c not in ("\n", "\r", "\t")
    )
    return (caracteres_de_controle / len(amostra)) > 0.02


def baixar_html(url: str) -> tuple:
    """Baixa o HTML de uma URL com múltiplas tentativas. Retorna (html, erro)."""
    aquecer_dominio(url)
    ultimo_erro = None

    for tentativa in range(MAX_TENTATIVAS_DOWNLOAD):
        user_agent = USER_AGENTS[tentativa % len(USER_AGENTS)]
        headers = montar_headers(user_agent)
        verificar_ssl = tentativa < MAX_TENTATIVAS_DOWNLOAD - 1

        try:
            resposta = SESSAO_HTTP.get(
                url, headers=headers, timeout=TIMEOUT_CONEXAO,
                allow_redirects=True, verify=verificar_ssl,
            )

            if resposta.status_code < 400:
                resposta.encoding = resposta.apparent_encoding or resposta.encoding
                texto_resposta = resposta.text

                if conteudo_parece_binario(texto_resposta):
                    # Conteúdo veio corrompido/comprimido de forma que não
                    # pôde ser decodificado como texto -- não usar esse
                    # resultado; tenta de novo com outro User-Agent.
                    ultimo_erro = "conteúdo binário/corrompido recebido (possível falha de descompressão)"
                    time.sleep(1.0)
                    continue

                return texto_resposta, None

            if resposta.status_code in CODIGOS_ERRO_DEFINITIVO:
                return None, f"HTTP {resposta.status_code}"

            ultimo_erro = f"HTTP {resposta.status_code}"
            time.sleep(1.5 if resposta.status_code in CODIGOS_POSSIVEL_BLOQUEIO_BOT else 1.0)
            continue

        except requests.exceptions.RequestException as exc:
            ultimo_erro = f"{type(exc).__name__}: {exc}"
            time.sleep(1.0)
            continue

    return None, ultimo_erro or "falha desconhecida"


def extrair_texto_fallback_bs4(html: str) -> str:
    """
    Extração alternativa e mais permissiva: reúne o texto de todos os
    parágrafos <p> da página (fora de menu/rodapé/scripts), descartando
    apenas trechos muito curtos (prováveis legendas soltas ou itens de
    menu). Serve como rede de segurança quando o trafilatura não consegue
    identificar o corpo do artigo.
    """
    try:
        soup = BeautifulSoup(html, "html.parser")
    except Exception:
        return ""

    for tag in soup(["script", "style", "nav", "footer", "header", "aside", "noscript", "form", "svg"]):
        tag.decompose()

    linhas = []
    for paragrafo in soup.find_all("p"):
        texto_p = paragrafo.get_text(" ", strip=True)
        if len(texto_p.split()) >= 5:
            linhas.append(texto_p)

    return "\n\n".join(linhas).strip()


def extrair_texto_noticia(noticia: dict) -> dict:
    """Baixa a página e extrai o texto principal, combinando duas estratégias."""
    html, erro_download = baixar_html(noticia["link"])

    if html is None:
        noticia["texto"] = None
        noticia["status"] = "Falha"
        noticia["motivo"] = f"falha ao baixar a página ({erro_download})"
        return noticia

    texto_trafilatura = None
    try:
        texto_trafilatura = trafilatura.extract(
            html,
            url=noticia["link"],
            include_comments=False,
            include_tables=False,
            favor_recall=True,
        )
    except Exception:
        texto_trafilatura = None

    texto_fallback = extrair_texto_fallback_bs4(html)

    candidatos = [t for t in (texto_trafilatura, texto_fallback) if t and t.strip()]
    texto_final = max(candidatos, key=len).strip() if candidatos else None

    if not texto_final or len(texto_final) < TAMANHO_MINIMO_TEXTO_VALIDO:
        noticia["texto"] = None
        noticia["status"] = "Falha"
        noticia["motivo"] = "conteúdo não pôde ser extraído (bloqueio, paywall ou página sem texto)"
        return noticia

    noticia["texto"] = texto_final
    noticia["status"] = "Sucesso"
    noticia["motivo"] = ""
    return noticia


def processar_em_paralelo(noticias: list, n_trabalhadores: int, rotulo: str) -> list:
    resultados = [None] * len(noticias)
    total = len(noticias)
    concluidos = 0

    with ThreadPoolExecutor(max_workers=n_trabalhadores) as executor:
        futuros = {
            executor.submit(extrair_texto_noticia, noticia): indice
            for indice, noticia in enumerate(noticias)
        }
        for futuro in as_completed(futuros):
            indice = futuros[futuro]
            noticia_processada = futuro.result()
            resultados[indice] = noticia_processada
            concluidos += 1
            status = noticia_processada["status"]
            detalhe = "" if status == "Sucesso" else f" - {noticia_processada['motivo']}"
            print(f"  [{rotulo} {concluidos}/{total}] {noticia_processada['jornal']}: {status}{detalhe}")

    return resultados


def coletar_todos_os_textos(noticias: list) -> list:
    """
    Coleta o texto de todas as notícias em duas rodadas:
    1) Rodada principal, com paralelismo maior.
    2) Segunda rodada, apenas para as que falharam na primeira -- muitas
       falhas são transitórias (limite de requisições, instabilidade),
       então tentar de novo depois de uma pequena pausa recupera boa
       parte das perdas.
    """
    print(f"\nColetando o conteúdo de {len(noticias)} notícia(s) "
          f"(até {MAX_TRABALHADORES_PARALELOS} por vez)...\n")
    resultados = processar_em_paralelo(noticias, MAX_TRABALHADORES_PARALELOS, "1ª rodada")

    falhas = [n for n in resultados if n["status"] == "Falha"]
    if falhas:
        print(f"\n{len(falhas)} notícia(s) falharam na 1ª rodada. "
              f"Aguardando {PAUSA_ANTES_DA_SEGUNDA_RODADA}s antes de tentar novamente...\n")
        time.sleep(PAUSA_ANTES_DA_SEGUNDA_RODADA)

        falhas_atualizadas = processar_em_paralelo(falhas, MAX_TRABALHADORES_SEGUNDA_RODADA, "2ª rodada")

        atualizadas_por_link = {n["link"]: n for n in falhas_atualizadas}
        for i, noticia in enumerate(resultados):
            if noticia["link"] in atualizadas_por_link:
                resultados[i] = atualizadas_por_link[noticia["link"]]

    return resultados


# --------------------------------------------------------------------------
# Etapa 3: Contar a frequência das palavras
# --------------------------------------------------------------------------
def contar_palavras(noticias: list) -> Counter:
    contador = Counter()
    padrao_palavra = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿ]+")

    for noticia in noticias:
        texto = noticia.get("texto")
        if not texto:
            continue
        for palavra in padrao_palavra.findall(texto.lower()):
            if len(palavra) < 3 or palavra in STOPWORDS_PT:
                continue
            contador[palavra] += 1

    return contador


# --------------------------------------------------------------------------
# Etapa 4: Gerar a planilha final (única), com 3 abas
# --------------------------------------------------------------------------
def valor_seguro_para_celula(valor):
    """
    Remove caracteres de controle não permitidos no formato XML usado pelo
    Excel (o que causaria IllegalCharacterError e travaria a geração da
    planilha) antes de gravar qualquer texto numa célula. Mantém tab,
    quebra de linha e retorno de carro, que são válidos.
    """
    if not isinstance(valor, str):
        return valor
    return ILLEGAL_CHARACTERS_RE.sub("", valor)


def truncar_para_celula(texto: str) -> str:
    texto = valor_seguro_para_celula(texto)
    if texto and len(texto) > LIMITE_CARACTERES_CELULA_EXCEL:
        return texto[:LIMITE_CARACTERES_CELULA_EXCEL] + "\n\n[...texto truncado - consulte o link original...]"
    return texto


def gerar_planilha_final(noticias: list, contador: Counter, candidato: str, caminho_saida: str) -> None:
    wb = Workbook()

    # --- Aba 1: notícias com o texto completo coletado ---
    ws_noticias = wb.active
    ws_noticias.title = "Noticias_Texto"

    ws_noticias.merge_cells("A1:E1")
    ws_noticias["A1"] = (
        f"Pesquisa: {candidato}  —  Gerado em {datetime.now().strftime('%d/%m/%Y %H:%M')}  —  "
        f"{len(noticias)} notícia(s) processada(s)"
    )
    ws_noticias["A1"].font = Font(bold=True, italic=True, size=12)

    cabecalhos = ["Jornal", "Título", "Link", "Status", "Texto Completo / Motivo da Falha"]
    for col, texto_cab in enumerate(cabecalhos, start=1):
        celula = ws_noticias.cell(row=2, column=col, value=texto_cab)
        celula.font = Font(bold=True, color="FFFFFF")
        celula.fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
        celula.alignment = Alignment(horizontal="center")

    fill_jornal = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
    fill_falha = PatternFill(start_color="F8CBAD", end_color="F8CBAD", fill_type="solid")

    # Agrupa por jornal, preservando a ordem de primeira aparição
    jornais_ordem = []
    por_jornal = {}
    for noticia in noticias:
        jornal = noticia["jornal"]
        if jornal not in por_jornal:
            por_jornal[jornal] = []
            jornais_ordem.append(jornal)
        por_jornal[jornal].append(noticia)

    linha_atual = 3
    for jornal in jornais_ordem:
        itens = por_jornal[jornal]
        sucesso_count = sum(1 for n in itens if n["status"] == "Sucesso")
        ws_noticias.cell(row=linha_atual, column=1, value=valor_seguro_para_celula(jornal))
        ws_noticias.cell(row=linha_atual, column=2, value=f"{sucesso_count}/{len(itens)} coletada(s) com sucesso")
        for col in range(1, 6):
            ws_noticias.cell(row=linha_atual, column=col).font = Font(bold=True)
            ws_noticias.cell(row=linha_atual, column=col).fill = fill_jornal
        linha_atual += 1

        for noticia in itens:
            ws_noticias.cell(row=linha_atual, column=2, value=valor_seguro_para_celula(noticia["titulo"]))
            celula_link = ws_noticias.cell(row=linha_atual, column=3, value=valor_seguro_para_celula(noticia["link"]))
            celula_link.hyperlink = noticia["link"]
            celula_link.font = Font(color="0563C1", underline="single")
            ws_noticias.cell(row=linha_atual, column=4, value=noticia["status"])

            if noticia["status"] == "Sucesso":
                conteudo = truncar_para_celula(noticia["texto"])
                ws_noticias.cell(row=linha_atual, column=5, value=conteudo)
            else:
                celula_motivo = ws_noticias.cell(
                    row=linha_atual, column=5, value=valor_seguro_para_celula(noticia["motivo"])
                )
                for col in range(1, 6):
                    ws_noticias.cell(row=linha_atual, column=col).fill = fill_falha

            ws_noticias.cell(row=linha_atual, column=5).alignment = Alignment(wrap_text=True, vertical="top")
            ws_noticias.row_dimensions[linha_atual].outlineLevel = 1
            linha_atual += 1

    ws_noticias.sheet_properties.outlinePr.summaryBelow = False
    ws_noticias.sheet_properties.outlinePr.summaryAbove = True
    larguras = {"A": 22, "B": 45, "C": 45, "D": 12, "E": 90}
    for col, largura in larguras.items():
        ws_noticias.column_dimensions[col].width = largura
    ws_noticias.freeze_panes = "A3"

    # --- Aba 2: frequência completa de todas as palavras ---
    ws_completa = wb.create_sheet("Frequencia_Completa")
    ws_completa["A1"] = "Palavra"
    ws_completa["B1"] = "Quantidade"
    for celula in ("A1", "B1"):
        ws_completa[celula].font = Font(bold=True, color="FFFFFF")
        ws_completa[celula].fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")

    palavras_ordenadas = contador.most_common()
    for i, (palavra, quantidade) in enumerate(palavras_ordenadas, start=2):
        ws_completa.cell(row=i, column=1, value=palavra)
        ws_completa.cell(row=i, column=2, value=quantidade)

    ws_completa.column_dimensions["A"].width = 30
    ws_completa.column_dimensions["B"].width = 15
    ws_completa.freeze_panes = "A2"

    # --- Aba 3: top 20 + gráfico ---
    ws_top = wb.create_sheet("Top20")
    ws_top.merge_cells("A1:B1")
    ws_top["A1"] = f"Top {TOP_N_PALAVRAS} palavras mais citadas — {candidato}"
    ws_top["A1"].font = Font(bold=True, size=13)

    ws_top["A2"] = "Palavra"
    ws_top["B2"] = "Quantidade"
    for celula in ("A2", "B2"):
        ws_top[celula].font = Font(bold=True, color="FFFFFF")
        ws_top[celula].fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
        ws_top[celula].alignment = Alignment(horizontal="center")

    top_20 = palavras_ordenadas[:TOP_N_PALAVRAS]
    for i, (palavra, quantidade) in enumerate(top_20, start=3):
        ws_top.cell(row=i, column=1, value=palavra)
        ws_top.cell(row=i, column=2, value=quantidade)

    ws_top.column_dimensions["A"].width = 25
    ws_top.column_dimensions["B"].width = 15

    if top_20:
        linha_final = 2 + len(top_20)
        grafico = BarChart()
        grafico.type = "col"
        grafico.title = f"Top {TOP_N_PALAVRAS} palavras mais citadas"
        grafico.y_axis.title = "Quantidade de repetições"
        grafico.x_axis.title = "Palavra"
        grafico.style = 10

        dados = Reference(ws_top, min_col=2, min_row=2, max_row=linha_final)
        categorias = Reference(ws_top, min_col=1, min_row=3, max_row=linha_final)
        grafico.add_data(dados, titles_from_data=True)
        grafico.set_categories(categorias)
        grafico.width = 26
        grafico.height = 13
        ws_top.add_chart(grafico, "D2")

    try:
        wb.save(caminho_saida)
    except IllegalCharacterError:
        # Rede de segurança final: se, por algum motivo, ainda restou um
        # caractere inválido em alguma célula (não deveria acontecer, já
        # que tudo passa por valor_seguro_para_celula), varre TODAS as
        # células de texto do workbook e sanitiza de novo antes de salvar,
        # em vez de perder a planilha inteira.
        print("    [AVISO] Caractere inválido detectado durante o salvamento -- "
              "higienizando todas as células e tentando novamente...")
        for aba in wb.worksheets:
            for linha_cels in aba.iter_rows():
                for cel in linha_cels:
                    if isinstance(cel.value, str):
                        cel.value = valor_seguro_para_celula(cel.value)
        wb.save(caminho_saida)


# --------------------------------------------------------------------------
# Escolha de diretório de saída
# --------------------------------------------------------------------------
def escolher_diretorio_destino() -> str:
    diretorio_padrao = os.getcwd()
    while True:
        entrada = input(
            f"\nEm qual pasta deseja salvar a planilha gerada? "
            f"(Enter para usar a pasta atual: {diretorio_padrao})\n> "
        ).strip()

        if not entrada:
            return diretorio_padrao

        caminho = os.path.abspath(os.path.expanduser(entrada))

        if os.path.isfile(caminho):
            print(f"    [ERRO] '{caminho}' é um arquivo, não uma pasta. Tente novamente.")
            continue
        if os.path.isdir(caminho):
            return caminho

        resposta = input(f"    A pasta '{caminho}' não existe. Deseja criá-la agora? (s/n) ").strip().lower()
        if resposta in ("s", "sim", "y", "yes"):
            try:
                os.makedirs(caminho, exist_ok=True)
                return caminho
            except OSError as exc:
                print(f"    [ERRO] Não foi possível criar a pasta: {exc}. Tente outro caminho.")
        else:
            print("    Ok, informe outro caminho.")


# --------------------------------------------------------------------------
# Programa principal
# --------------------------------------------------------------------------
def main():
    print("=" * 70)
    print("Análise de conteúdo das notícias coletadas")
    print("=" * 70)

    caminhos_planilhas = escolher_planilhas_entrada()
    noticias = combinar_planilhas(caminhos_planilhas)

    if not noticias:
        sys.exit("Nenhum link válido foi encontrado nas planilhas informadas. Encerrando.")

    candidato = input(
        "\nDigite o nome do candidato (usado para nomear o arquivo gerado "
        "e o título da planilha): "
    ).strip() or "candidato"

    noticias_processadas = coletar_todos_os_textos(noticias)

    sucesso = sum(1 for n in noticias_processadas if n["status"] == "Sucesso")
    falha = len(noticias_processadas) - sucesso
    print(f"\nColeta concluída: {sucesso}/{len(noticias_processadas)} texto(s) extraído(s) com sucesso "
          f"({falha} perda(s) definitiva(s)).")

    diretorio_destino = escolher_diretorio_destino()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    candidato_slug = "_".join(candidato.strip().split())
    caminho_xlsx = os.path.join(diretorio_destino, f"analise_noticias_{candidato_slug}_{timestamp}.xlsx")

    print("\nContando a frequência das palavras...")
    contador = contar_palavras(noticias_processadas)
    if contador:
        print(f"    {len(contador)} palavra(s) distinta(s) encontrada(s).")
        print(f"\nTop {TOP_N_PALAVRAS} palavras mais citadas:")
        for posicao, (palavra, quantidade) in enumerate(contador.most_common(TOP_N_PALAVRAS), start=1):
            print(f"    {posicao:>2}. {palavra} — {quantidade}")
    else:
        print("    [AVISO] Nenhuma palavra pôde ser contabilizada (nenhum texto extraído com sucesso).")

    print("\nGerando planilha final (notícias + frequência + ranking/gráfico)...")
    try:
        gerar_planilha_final(noticias_processadas, contador, candidato, caminho_xlsx)
    except Exception as exc:
        # Nunca perder o trabalho de coleta (a etapa mais demorada) por um
        # erro na geração da planilha: salva um backup bruto dos dados em
        # JSON, para permitir gerar a planilha depois sem repetir a coleta.
        caminho_backup = os.path.join(
            diretorio_destino, f"BACKUP_dados_coletados_{candidato_slug}_{timestamp}.json"
        )
        print(f"    [ERRO] Falha ao gerar a planilha: {exc}")
        print(f"    Salvando backup bruto dos dados coletados em: {caminho_backup}")
        import json
        with open(caminho_backup, "w", encoding="utf-8") as arquivo_backup:
            json.dump(noticias_processadas, arquivo_backup, ensure_ascii=False, indent=2)
        print("    Backup salvo. Você não precisa refazer a coleta -- me avise para eu ajustar o script.")
        raise

    print(f"    Planilha salva em: {caminho_xlsx}")

    print("\nConcluído!")


if __name__ == "__main__":
    main()
